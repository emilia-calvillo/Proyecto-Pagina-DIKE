<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicia Sesión</title>

    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="header2"> 
        <div class="menu container"> 
            <a href="#" class="logo">Logo</a>
            <input type="checkbox" id="menu"/>
            <label for="menu"> 
                <img src="assets/menu.png" class="menu-icono" alt="">
            </label>
            <nav class="navbar">
                <ul>
                    <li><a href="HomeAdmin.html">Inicio</a></li>
                    <li><a href="CasosAdmin.php">Casos Abiertos</a></li>
                    <li><a href="AgendaClientesAdmin.php">Clientes Activos</a></li>
                    <li><a href="CreaUserAdmin.php">Crear usuario</a></li>
                    <li><a href="logout.php">Cerrar Sesión</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="second_body"> 
        <div class="next_body">
        <form action="" class="formulario" method="POST">
            <h2>Crear nueva cuenta</h2>
            <br>
            <label for="" class="formulario_label">Usuario</label>
            <input type="text" name="user" class="formulario_input">
            <br> <br>
            <label for="" class="formulario_label">Contraseña</label>
            <input type="password" name="pass" class="formulario_pass">
            <br> <br>
            <input type="submit" name="CrearUser" value="Crear como Cliente">
            <br> <br>
            <input type="submit" name="CrearAdmin" value="Crear como Administrador">
        </form>
        <?php
            include("registrar.php");
        ?>
        </div>
    </section>


    <footer class="footer">
        <div class="footer-content container">
            <div class="link">
                <h3>Estado y código postal</h3>
                <ul>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                </ul>
            </div>
            <div class="link">
                <h3>Redes Sociales</h3>
                <ul>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                </ul>
            </div>
        </div>
    </footer>
</body>
</html>