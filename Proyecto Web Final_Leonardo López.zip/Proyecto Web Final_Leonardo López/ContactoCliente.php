<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacto</title>

    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="header2"> 
        <div class="menu container"> 
            <a href="#" class="logo">Logo</a>
            <input type="checkbox" id="menu"/>
            <label for="menu"> 
                <img src="assets/menu.png" class="menu-icono" alt="">
            </label>
            <nav class="navbar">
                <ul>
                    <li><a href="HomeCliente.html">Inicio</a></li>
                    <li><a href="CasosCliente.php">Mis Casos</a></li>
                    <li><a href="ServiciosCliente.html">Servicios</a></li>
                    <li><a href="NosotrosCliente.html">Nosotros</a></li>
                    <li><a href="ContactoCliente.php">Contacto</a></li>
                    <li><a href="logout.php">Cerrar Sesión</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="second_body">
        <div class="next_body">
            <div class="body_container">
            <h2 class="contact_title">¿Dudas de algún caso? Contáctanos</h2>
                <div class="izquierda">
                <p class="contact_text">Puede enviar su consulta a través del siguiente formulario<br>
                    Teléfono: <strong>215664 489465</strong><br>
                    Email: <a href="mailto: DespachoDike@gmail.com">DespachoDike@gmail.com</a>
                </p>
                </div>
                <div class="derecha">
                <form action="" method="POST" class="contact_form">
                    <input type="text" name="nombre" placeholder="Ingrese su nombre" class="email-asunto">
                    <br>
                    <input type="email" name="correo" placeholder="Ingrese su correo" class="email-asunto">
                    <br>
                    <input type="text" name="asunto" placeholder="Ingrese su asunto" class="email-asunto">
                    <br>
                    <textarea name="mensaje" placeholder="Ingrese su mensaje" class="mensaje"></textarea>
                    <br>
                    <input type="submit" name="enviar" value="Enviar consulta">
                </form>
                <?php
                    include("enviaformulario.php");
                ?>
                </div>
            </div>
            <div class="mapa">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d342.9293881459022!2d-100.99089841690748!3d22.139721267819603!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x842a99df6c0aed7d%3A0xb275ec7abcdff37a!2sDuque%20Banda%20Asociados!5e0!3m2!1ses-419!2smx!4v1701575531309!5m2!1ses-419!2smx" width="800" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
            
        </div>
    </section>


    <footer class="footer">
        <div class="footer-content container">
            <div class="link">
                <h3>Estado y código postal</h3>
                <ul>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                </ul>
            </div>
            <div class="link">
                <h3>Redes Sociales</h3>
                <ul>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                </ul>
            </div>
        </div>
    </footer>
</body>
</html>