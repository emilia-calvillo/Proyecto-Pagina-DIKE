<?php
    include("conexion.php");

    if(isset($_POST['Eliminar'])){
        if(strlen($_POST['user']) >= 1) {
            $name = trim($_POST['user']);

            $consulta = "DELETE FROM `users` WHERE usuario = '$name'";
            $resultado = mysqli_query($conex,$consulta);

            if($resultado) {
                ?>
                <h3>Registro eliminado</h3>
                <?php
            } else {
                ?>
                <h3>Ocurrió un error</h3>
                <?php
            }
        } else {
            ?>
            <h3>Por favor, complete los campos</h3>
            <?php
        }
    }
?>