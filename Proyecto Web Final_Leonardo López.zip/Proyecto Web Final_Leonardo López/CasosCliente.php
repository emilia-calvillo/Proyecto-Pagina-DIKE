<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicia Sesión</title>

    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="header2"> 
        <div class="menu container"> 
            <a href="#" class="logo">Logo</a>
            <input type="checkbox" id="menu"/>
            <label for="menu"> 
                <img src="assets/menu.png" class="menu-icono" alt="">
            </label>
            <nav class="navbar">
                <ul>
                    <li><a href="HomeCliente.html">Inicio</a></li>
                    <li><a href="CasosCliente.php">Mis Casos</a></li>
                    <li><a href="ServiciosCliente.html">Servicios</a></li>
                    <li><a href="NosotrosCliente.html">Nosotros</a></li>
                    <li><a href="ContactoCliente.php">Contacto</a></li>
                    <li><a href="logout.php">Cerrar Sesión</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="second_body"> 
        <div class="next_body">
        <?php
            include("mostrarcarpetascliente.php");
        ?>
        </div>
    </section>


    <footer class="footer">
        <div class="footer-content container">
            <div class="link">
                <h3>Estado y código postal</h3>
                <ul>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                </ul>
            </div>
            <div class="link">
                <h3>Redes Sociales</h3>
                <ul>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                    <li><a href="#">algo</a></li>
                </ul>
            </div>
        </div>
    </footer>
</body>
</html>