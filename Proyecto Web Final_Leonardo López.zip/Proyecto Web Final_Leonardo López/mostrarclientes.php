<?php

    $inc = include("conexion.php");

    if($inc) {
        $consulta = "SELECT * FROM users";
        $resultado = mysqli_query($conex,$consulta);

        if($resultado) {
            while($row = $resultado->fetch_array()){
                $user = $row['usuario'];
                $pass = $row['contraseña'];
                ?>
                <div>
                    <h3><?php echo $user; ?></h3>
                    <div>
                        <p>
                            <b> Contraseña: </b> <?php echo $pass; ?><br>
                        </p>
                    </div>
                </div>
                <?php
            }
        }
    }

?>