<?php
    include("conexion.php");

    if(isset($_POST['CrearUser'])){
        if(strlen($_POST['user']) >= 1 && strlen($_POST['pass']) >= 1) {
            $name = trim($_POST['user']);
            $password = trim($_POST['pass']);

            $consulta = "INSERT INTO `users`(`usuario`, `contraseña`) VALUES ('$name','$password')";
            $resultado = mysqli_query($conex,$consulta);

            if($resultado) {
                ?>
                <h3>Registro correcto</h3>
                <?php
            } else {
                ?>
                <h3>Ocurrió un error</h3>
                <?php
            }
        } else {
            ?>
            <h3>Por favor, complete los campos</h3>
            <?php
        }
    }

    if(isset($_POST['CrearAdmin'])){
        if(strlen($_POST['user']) >= 1 && strlen($_POST['pass']) >= 1) {
            $name = trim($_POST['user']);
            $password = trim($_POST['pass']);

            $consulta = "INSERT INTO `admins`(`useradmin`, `contraseña`) VALUES ('$name','$password')";
            $resultado = mysqli_query($conex,$consulta);

            if($resultado) {
                ?>
                <h3>Registro correcto</h3>
                <?php
            } else {
                ?>
                <h3>Ocurrió un error</h3>
                <?php
            }
        } else {
            ?>
            <h3>Por favor, complete los campos</h3>
            <?php
        }
    }
?>