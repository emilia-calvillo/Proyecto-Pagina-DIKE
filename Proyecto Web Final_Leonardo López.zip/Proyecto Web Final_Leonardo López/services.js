(function(){
    const titleService = [...document.querySelectorAll('.services_title')];

    titleService.forEach(service =>{
        service.addEventListener('click', ()=>{
            let height = 0;
            let description = service.nextElementSibling;
            let addPadding = service.parentElement.parentElement;

            addPadding.classList.toggle('services_padding--add');
            service.children[0].classList.toggle('services_arrow--rotate');

            if(description.clientHeight === 0){
                height = description.scrollHeight;
            }

            description.style.height = `${height}px`;
        });
    });
})();