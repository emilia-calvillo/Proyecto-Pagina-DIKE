<?php
    include("conexion.php");

    if(isset($_POST['Subir'])){
        if(strlen($_POST['title']) >= 1 && strlen($_POST['user']) >= 1 && strlen($_POST['details']) >= 1) {
            $title = trim($_POST['title']);
            $name = trim($_POST['user']);
            $details = trim($_POST['details']);

            $consulta = "INSERT INTO `carpetas_casos`(`titulo`, `user_cliente`, `detalles`) VALUES ('$title', '$name','$details')";
            $resultado = mysqli_query($conex,$consulta);

            if($resultado) {
                ?>
                <h3>Se creo exitosamente</h3>
                <?php
            } else {
                ?>
                <h3>Ocurrió un error</h3>
                <?php
            }
        } else {
            ?>
            <h3>Por favor, complete los campos</h3>
            <?php
        }
    }
?>