<?php
    include("conexion.php");

    if(isset($_POST['IngresarUser'])){
        if(strlen($_POST['user']) >= 1 && strlen($_POST['pass']) >= 1) {
            $name = trim($_POST['user']);
            $password = trim($_POST['pass']);

            $consulta = "SELECT COUNT(*) as login FROM users WHERE usuario='" .$name. "' AND contraseña='" .$password."'";
            $query = mysqli_query($conex,$consulta);
            $row = mysqli_fetch_array($query);

            session_start();
            if($row['login'] > 0){
            //Login exitoso
            //Establecer sesión
            $_SESSION['user'] = $name;
            //Redireccionar
            header("Location: http://localhost/Proyecto%20Web%20Final_Leonardo%20L%C3%B3pez/HomeCliente.html");
            }else{
            //Login incorrecto
            //header("Location: http://localhost/Proyecto%20Web%20Final_Leonardo%20L%C3%B3pez/IniciaSesi%C3%B3n.php");
            ?>
            <h3>No se encuentra registrado como Cliente</h3>
            <?php
            }   
        } else {
            ?>
            <h3>Por favor, complete los campos</h3>
            <?php
        }
    }

    if(isset($_POST['IngresarAdmin'])){
        if(strlen($_POST['user']) >= 1 && strlen($_POST['pass']) >= 1) {
            $name = trim($_POST['user']);
            $password = trim($_POST['pass']);

            $consulta = "SELECT COUNT(*) as login FROM admins WHERE useradmin='" .$name. "' AND contraseña='" .$password."'";
            $query = mysqli_query($conex,$consulta);
            $row = mysqli_fetch_array($query);

            session_start();
            if($row['login'] > 0){
            //Login exitoso
            //Establecer sesión
            $_SESSION['user'] = $name;
            //Redireccionar
            header("Location: http://localhost/Proyecto%20Web%20Final_Leonardo%20L%C3%B3pez/HomeAdmin.html");
            }else{
            //Login incorrecto
            //header("Location: http://localhost/Proyecto%20Web%20Final_Leonardo%20L%C3%B3pez/IniciaSesi%C3%B3n.php");
            ?>
            <h3>No se encuentra registrado como Administrador</h3>
            <?php
            }   
        } else {
            ?>
            <h3>Por favor, complete los campos</h3>
            <?php
        }
    }

?>