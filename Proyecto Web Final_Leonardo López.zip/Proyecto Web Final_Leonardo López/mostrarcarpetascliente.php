<?php

    $inc = include("conexion.php");
    include("login.php");

    if($inc) {
        $name = $_SESSION['user'];
        $consulta = "SELECT * FROM `carpetas_casos` WHERE user_cliente = '$name'";
        $resultado = mysqli_query($conex,$consulta);

        if($resultado) {
            while($row = $resultado->fetch_array()){
                $title = $row['titulo'];
                $user = $row['user_cliente'];
                $details = $row['detalles'];
                ?>
                <div>
                    <h3><?php echo $title; ?></h3>
                    <div>
                        <p>
                            <b> Cliente: </b> <?php echo $user; ?><br>
                            <b> Detalles: </b> <?php echo $details; ?><br>
                        </p>
                    </div>
                </div>
                <?php
            }
        }
    }

?>