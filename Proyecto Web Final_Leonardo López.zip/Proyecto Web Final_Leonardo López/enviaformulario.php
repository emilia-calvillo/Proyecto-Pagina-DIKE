<?php
    include("conexion.php");

    if(isset($_POST['enviar'])){
        if(strlen($_POST['nombre']) >= 1 && strlen($_POST['correo']) >= 1 && strlen($_POST['asunto']) >= 1 && strlen($_POST['mensaje']) >= 1) {
            $name = trim($_POST['nombre']);
            $email = trim($_POST['correo']);
            $issue = trim($_POST['asunto']);
            $message = trim($_POST['mensaje']);

            $consulta = "INSERT INTO `consultas`(`nombre`, `correo`, `asunto`, `mensaje`) VALUES ('$name','$email','$issue','$message')";
            $resultado = mysqli_query($conex,$consulta);

            if($resultado) {
                ?>
                <h3>Envio correcto</h3>
                <?php
            } else {
                ?>
                <h3>Ocurrió un error</h3>
                <?php
            }
        } else {
            ?>
            <h3>Por favor, llene todos los campos</h3>
            <?php
        }
    }
?>