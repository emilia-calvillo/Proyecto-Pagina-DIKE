<?php
    session_start();
    session_destroy();
    header("Location: http://localhost/Proyecto%20Web%20Final_Leonardo%20L%C3%B3pez/Home.html");
?>